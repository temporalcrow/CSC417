import ClassTable from './Table';


function App() {
  return (
    <div className="App">
      <ClassTable name ="Drew Lebo" id="0979419" enrollDate = "Fall 2021"/>
    </div>
  );
}

export default App;
